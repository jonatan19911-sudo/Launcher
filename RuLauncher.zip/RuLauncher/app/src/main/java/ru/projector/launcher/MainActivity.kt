package ru.projector.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.util.Locale

class MainActivity : Activity() {

    private class App(val pkg: String, val activity: String, val label: String, val icon: Drawable)

    private val apps = mutableListOf<App>()
    private lateinit var adapter: BaseAdapter
    private val prefs by lazy { getSharedPreferences("names", Context.MODE_PRIVATE) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun box(fill: Int, stroke: Int) = GradientDrawable().apply {
        cornerRadius = dp(12).toFloat()
        setColor(fill)
        setStroke(dp(3), stroke)
    }

    private fun focusBg() = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_focused), box(0x44FFFFFF, Color.WHITE))
        addState(intArrayOf(), box(0x14FFFFFF, Color.TRANSPARENT))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Locale.setDefault(Locale("ru"))

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF101820.toInt())
            setPadding(dp(32), dp(24), dp(32), dp(16))
        }

        // Шапка: время и дата
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextClock(this).apply {
            format24Hour = "HH:mm"; format12Hour = "HH:mm"
            textSize = 40f; setTextColor(Color.WHITE)
        })
        header.addView(TextClock(this).apply {
            format24Hour = "EEEE, d MMMM"; format12Hour = "EEEE, d MMMM"
            textSize = 18f; setTextColor(0xFFB0BEC5.toInt()); setPadding(dp(20), 0, 0, 0)
        })
        root.addView(header)

        // Быстрые настройки на русском
        val quick = LinearLayout(this).apply { setPadding(0, dp(16), 0, dp(16)) }
        listOf(
            "Wi-Fi" to Settings.ACTION_WIFI_SETTINGS,
            "Bluetooth" to Settings.ACTION_BLUETOOTH_SETTINGS,
            "Язык" to Settings.ACTION_LOCALE_SETTINGS,
            "Экран" to Settings.ACTION_DISPLAY_SETTINGS,
            "Звук" to Settings.ACTION_SOUND_SETTINGS,
            "Все настройки" to Settings.ACTION_SETTINGS
        ).forEach { (title, action) ->
            quick.addView(TextView(this).apply {
                text = title; textSize = 18f; setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                setPadding(dp(20), dp(12), dp(20), dp(12))
                background = focusBg()
                isFocusable = true; isClickable = true
                setOnClickListener { open(Intent(action)) }
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { rightMargin = dp(12) })
        }
        root.addView(quick)

        // Сетка приложений
        adapter = object : BaseAdapter() {
            override fun getCount() = apps.size
            override fun getItem(p: Int) = apps[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, v: View?, parent: ViewGroup): View {
                val app = apps[p]
                val cell = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    setPadding(dp(8), dp(12), dp(8), dp(12))
                }
                cell.addView(ImageView(this@MainActivity).apply { setImageDrawable(app.icon) },
                    LinearLayout.LayoutParams(dp(64), dp(64)))
                cell.addView(TextView(this@MainActivity).apply {
                    text = app.label; textSize = 15f; setTextColor(Color.WHITE)
                    gravity = Gravity.CENTER; maxLines = 2
                    ellipsize = android.text.TextUtils.TruncateAt.END
                    setPadding(0, dp(8), 0, 0)
                })
                return cell
            }
        }

        val grid = GridView(this).apply {
            numColumns = 6
            adapter = this@MainActivity.adapter
            selector = focusBg()
            horizontalSpacing = dp(8); verticalSpacing = dp(8)
            clipToPadding = false
            setOnItemClickListener { _, _, pos, _ ->
                val a = apps[pos]
                open(Intent(Intent.ACTION_MAIN).setClassName(a.pkg, a.activity))
            }
            // Долгое нажатие OK: переименовать приложение (перевести название)
            setOnItemLongClickListener { _, _, pos, _ -> rename(apps[pos]); true }
        }
        root.addView(grid, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        loadApps()
    }

    // Кнопка «Назад» не должна закрывать главный экран
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {}

    private fun loadApps() {
        val pm = packageManager
        val found = linkedMapOf<String, App>()
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val query = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (ri in pm.queryIntentActivities(query, 0)) {
                val ai = ri.activityInfo
                if (ai.packageName == packageName || ai.packageName in found) continue
                val name = prefs.getString(ai.packageName, null) ?: ri.loadLabel(pm).toString()
                found[ai.packageName] = App(ai.packageName, ai.name, name, ri.loadIcon(pm))
            }
        }
        apps.clear()
        apps.addAll(found.values.sortedBy { it.label.lowercase() })
        adapter.notifyDataSetChanged()
    }

    private fun rename(app: App) {
        val input = EditText(this).apply { setText(app.label) }
        AlertDialog.Builder(this)
            .setTitle("Название приложения")
            .setView(input)
            .setPositiveButton("Сохранить") { _, _ ->
                prefs.edit().putString(app.pkg, input.text.toString()).apply(); loadApps()
            }
            .setNeutralButton("Сбросить") { _, _ ->
                prefs.edit().remove(app.pkg).apply(); loadApps()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun open(intent: Intent) {
        try {
            startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось открыть", Toast.LENGTH_SHORT).show()
        }
    }
}
